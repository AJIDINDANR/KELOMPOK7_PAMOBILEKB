package com.example.tabularapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
